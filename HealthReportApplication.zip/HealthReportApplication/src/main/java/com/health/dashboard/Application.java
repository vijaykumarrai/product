package com.health.dashboard;

import java.util.List;

public class Application {

	/**
	 * 1. Entry point for the application. 2. Call getEHRData method with
	 * period, sort field, sororder. 3. Call printEHRNotes method to display the
	 * results to the console.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		Service service = new Service();
		/*
		 * Invoke the service with period as 2014.
		 */
		List<List<String>> EHRReport = service.getEHRData("2014", null, null);

		/*
		 * Display the result to the console.
		 */
		printEHRNotes(EHRReport);
	}

	/**
	 * Iterate the EHRReport and display the results to the console.
	 * 
	 * @param EHRReport
	 * @return void
	 */
	public static void printEHRNotes(List<List<String>> EHRReport) {
		System.out.println("==================================================================================");

		for (List<String> entry : EHRReport) {
			System.out.println("Region		:	" + entry.get(0));
			System.out.println("Period		:	" + entry.get(1));

			System.out.println("Hospitals EHR 		:	" + entry.get(2) + "%");
			System.out.println("Rural Hospitals EHR 	:	" + entry.get(3) + "%");
			System.out.println("Small Hospitals EHR 	:	" + entry.get(4) + "%");
			System.out.println("Critical Hospitals EHR 	:	" + ("".equals(entry.get(5)) ? "-" : entry.get(5) + "%"));

			System.out.println("==================================================================================");
		}
	}
}
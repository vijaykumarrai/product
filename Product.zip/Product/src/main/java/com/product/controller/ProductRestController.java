package com.product.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.product.model.Item;
import com.product.model.ResultItem;
import com.product.service.ProductService;

@RestController("/")
public class ProductRestController {
	// @Autowired
	ProductService service = new ProductService();

	/**
	 * Add new product with sellInDate and quality value
	 * 
	 * @param item
	 * @param model
	 * @return String
	 */
	@PostMapping("/add")
	public ResponseEntity<String> addProduct(@RequestBody Item item, Model model) {
		service.addProduct(item);
		return new ResponseEntity<String>("{\"message\":\"Product added successfully\"}", HttpStatus.OK);
	}

	/**
	 * Return the list of products with sellInDate and quality value for the given date
	 * @param reportDate
	 * @return List<ResultItem>
	 * @throws ParseException
	 */
	@GetMapping("/productsList/{reportDate}")
	public ResponseEntity<List<ResultItem>> getProductList(@PathVariable("reportDate") String reportDate)
			throws ParseException {
		List<ResultItem> items = service.getProductList(reportDate);
		return new ResponseEntity<List<ResultItem>>(items, HttpStatus.OK);
	}

}
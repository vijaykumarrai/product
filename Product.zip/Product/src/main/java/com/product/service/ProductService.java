package com.product.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.product.model.Item;
import com.product.model.QualityDetails;
import com.product.model.ResultItem;
import com.product.repository.ProductData;
import com.product.util.CommonUtil;

@Service
public class ProductService {
	/**
	 * Add new product to the repository
	 * 
	 * @param item
	 */
	public void addProduct(Item item) {
		item.setEntryDate(CommonUtil.getDate());
		Date sellInDate = CommonUtil.getDate();
		sellInDate.setDate(sellInDate.getDate() + item.getSellIn());
		item.setSellDate(sellInDate);
		ProductData.getProductsList().add(item);
	}

	/**
	 * Get the list of products registered currently
	 * 
	 * @param reportDate
	 * @return List<ResultItem>
	 */
	public List<ResultItem> getProductList(String reportDate) {
		Date inputDate = CommonUtil.getDate(reportDate);
		List<ResultItem> result = new ArrayList();
		for (Item item : ProductData.getProductsList()) {
			result.add(getProcessedItem(item, inputDate));
		}
		return result;
	}

	/**
	 * Calculate the quality for each item
	 * 1.	get the date based decrement and sellIn special rules as QualityDetails
	 * 2.	create result object set sellIn as per the rules like sellDate crossed or
		 	Items like sufuras which is never sold calculate the quality and set in
		 	result object
		3.	quality of an item cannot be negetive or more than 50
	 * @param item
	 * @param reportDate
	 * @return
	 */
	public ResultItem getProcessedItem(Item item, Date reportDate) {
		ResultItem item1 = new ResultItem();
		item1.setName(item.getName());

		QualityDetails qualityDetails = CommonUtil.getQualityDetails(item.getName());

		setSellIn(item1, qualityDetails.isNeverSold(), CommonUtil.getDateDiff(item.getSellDate(), reportDate));
		setQuality(item1, qualityDetails, reportDate, item);

		checkQualityRules(item1);

		return item1;
	}

	/**
	 * Set sellIn date based on item never sold or sold and sellIn date is in future
	 * 
	 * @param item
	 * @param neverSold
	 * @param sellDiff
	 */
	public void setSellIn(ResultItem item, boolean neverSold, int sellDiff) {
		if (neverSold) {
			item.setSellIn(0);
		} else {
			item.setSellIn(sellDiff > 0 ? sellDiff : 0);
		}
	}

	/**
	 * Calculate the quality basedon the date requested
	 * 
	 * @param item1
	 * @param qualityDetails
	 * @param reportDate
	 * @param item
	 */
	private void setQuality(ResultItem item1, QualityDetails qualityDetails, Date reportDate, Item item) {
		/* get the difference between the entryDate, sellInDate, reportDate */
		int sellInToReportDiff = CommonUtil.getDateDiff(item.getSellDate(), reportDate);
		int entryToReportDateDiff = CommonUtil.getDateDiff(reportDate, item.getEntryDate());
		int daysAfterSellDate = CommonUtil.getDateDiff(reportDate, item.getSellDate());
		int entryDateToSellDate = CommonUtil.getDateDiff(item.getSellDate(), item.getEntryDate());
		
		if (entryDateToSellDate > 10) {
			if (daysAfterSellDate <= 0) { // item registered before 10 days and reportDate<sellDate.
				if (sellInToReportDiff > 10) {
					item1.setQuality(item.getQuality() - (entryToReportDateDiff * qualityDetails.getDecrement()));
				} else {
					int first = entryDateToSellDate - 10;
					item1.setQuality(item.getQuality() - (first * qualityDetails.getDecrement())
							- ((entryDateToSellDate - sellInToReportDiff - first)
									* qualityDetails.getDecrementBefore10()));
				}
			} else {// item registered before 10 days and reportDate>sellDate.
				if (qualityDetails.isZeroAfterSellDate()) {
					item1.setQuality(0);
				} else {
					int firstDecrement = (entryDateToSellDate - 10) * qualityDetails.getDecrement();
					int tenDaysBefore = 10 * qualityDetails.getDecrementBefore10();
					int afterDecrement = daysAfterSellDate * qualityDetails.getDecrementAfterSellDate();
					item1.setQuality(item.getQuality() - firstDecrement - tenDaysBefore - afterDecrement);
				}
			}
		} else {
			if (daysAfterSellDate <= 0) {
				item1.setQuality(item.getQuality() - (entryToReportDateDiff * qualityDetails.getDecrementBefore10()));
			} else {
				if (qualityDetails.isZeroAfterSellDate()) {
					item1.setQuality(0);
				} else {
					item1.setQuality(item.getQuality() - (entryDateToSellDate * qualityDetails.getDecrementBefore10())
							- (daysAfterSellDate * qualityDetails.getDecrementAfterSellDate()));
				}
			}
		}
	}

	/**
	 * Check the quality valuenot negetive or not more than 50
	 * 
	 * @param item1
	 */
	private void checkQualityRules(ResultItem item1) {
		if (item1.getQuality() < 0)
			item1.setQuality(0);
		if (item1.getQuality() > 50)
			item1.setQuality(50);
	}

}

package com.product.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import com.product.model.QualityDetails;
import com.product.repository.ProductData;

public class CommonUtil {
	public static Date getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date dateWithoutTime = null;
		try {
			dateWithoutTime = sdf.parse(sdf.format(new Date()));
		} catch (ParseException e) {
			System.out.println("exception " + e);
		}
		return dateWithoutTime;
	}

	public static Date getDate(String date) {
		try {
			return new SimpleDateFormat("dd-MM-yyyy").parse(date);
		} catch (ParseException e) {
			return null;
		}
	}

	public static int getDateDiff(Date date1, Date date2) {
		long diffInMillies = date1.getTime() - date2.getTime();
		int diff = (int) TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		return diff;
	}

	public static QualityDetails getQualityDetails(String name) {
		QualityDetails qualityDetails = ProductData.getProductQualityMap().get(name);
		if (qualityDetails == null) {
			qualityDetails = ProductData.getProductQualityMap().get("Default");
		}
		return qualityDetails;
	}
}

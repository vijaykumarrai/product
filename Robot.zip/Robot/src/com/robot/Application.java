package com.robot;

import com.robot.executor.DriveExecutor;

public class Application {

	public static void main(String[] args) {

		// swerve drive
		String swervefilePath = "C:\\work\\test1\\Robot\\src\\resources\\SwerveDrive.txt";
		DriveExecutor.executeSingleDrive(swervefilePath, "Swerve");

		// arcade drive
		String arcadeFilePath = "C:\\work\\test1\\Robot\\src\\resources\\ArcadeDrive.txt";
		DriveExecutor.executeSingleDrive(arcadeFilePath, "Arcade");
	}

}

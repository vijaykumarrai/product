package com.robot.drive;

import java.util.List;

public interface SingleJoyStickDrive {
	
	public void forward();

	public void backward();

	public void left();

	public void right();
	
	public void startDrive(List<String> input) throws Exception;
}
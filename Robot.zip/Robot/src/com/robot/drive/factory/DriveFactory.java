package com.robot.drive.factory;

import com.robot.drive.SingleJoyStickDrive;
import com.robot.drive.impl.ArcadeDrive;
import com.robot.drive.impl.SwerveDrive;
import com.robot.drive.model.Robot;
import com.robot.util.Constants;

public class DriveFactory {

	public static SingleJoyStickDrive getDrive(String drive) {
		SingleJoyStickDrive instance = null;
		Robot robot = new Robot();

		if (Constants.DRIVE_SWERVE.equals(drive)) {
			instance = new SwerveDrive(robot);
		} else if (Constants.DRIVE_ARCADE.equals(drive)) {
			instance = new ArcadeDrive(robot);
		}
		
		return instance;
	}
}
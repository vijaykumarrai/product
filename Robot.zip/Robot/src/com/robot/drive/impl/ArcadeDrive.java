package com.robot.drive.impl;

import java.util.List;

import com.robot.drive.SingleJoyStickDrive;
import com.robot.drive.model.Robot;

public class ArcadeDrive implements SingleJoyStickDrive {
	Robot robot;

	public ArcadeDrive(Robot robot) {
		this.robot = robot;
	}

	@Override
	public void forward() {
		robot.incrementY();
	}

	@Override
	public void backward() {
		robot.decrementY();
	}

	@Override
	public void left() {
		robot.decrementX();
		forward();
		turnLeft();
	}

	@Override
	public void right() {
		robot.incrementX();
		forward();
		turnRight();
	}

	private void turnLeft() {
		if ("E".equals(robot.getDirection()))
			robot.setDirection("N");
		else if ("W".equals(robot.getDirection()))
			robot.setDirection("S");
		else if ("N".equals(robot.getDirection()))
			robot.setDirection("W");
		else if ("S".equals(robot.getDirection()))
			robot.setDirection("E");
	}

	private void turnRight() {
		if ("E".equals(robot.getDirection()))
			robot.setDirection("S");
		else if ("W".equals(robot.getDirection()))
			robot.setDirection("N");
		else if ("N".equals(robot.getDirection()))
			robot.setDirection("E");
		else if ("S".equals(robot.getDirection()))
			robot.setDirection("W");
	}

	public void startDrive(List<String> input) {
		try {
			System.out
					.println("(" + robot.getX() + "," + robot.getY() + ")" + robot.getDirection() + " starting point");
			for (String command : input) {
				if ("F".equals(command)) {
					forward();
				}
				if ("B".equals(command)) {
					backward();
				}
				if ("R".equals(command)) {
					right();
				}
				if ("L".equals(command)) {
					left();
				}
				System.out.println("(" + robot.getX() + "," + robot.getY() + ")" + robot.getDirection());
			}
		} catch (Exception e) {
			System.out.println("exception in startDrive method." + e);
		}
		System.out.println("-------------------------------------------");
	}
}
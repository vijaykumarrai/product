package com.robot.drive;

import java.util.List;

public interface DoubleStickDrive extends Drive {

	// each entry will have 2 entries from 2 joysticks
	public void startDrive(List<String[]> input) throws Exception;
}

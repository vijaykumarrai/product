package com.robot.drive;

public interface Drive {
	
	public void forward();

	public void backward();

	public void left();

	public void right();
	
}

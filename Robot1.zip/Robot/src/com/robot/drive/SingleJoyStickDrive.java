package com.robot.drive;

import java.util.List;

public interface SingleJoyStickDrive extends Drive {

	public void startDrive(List<String> input) throws Exception;
	
}
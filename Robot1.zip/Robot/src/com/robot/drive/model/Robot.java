package com.robot.drive.model;

import com.robot.util.Constants;

public class Robot {
	private int x;
	private int y;
	private String direction;

	public Robot() {
		x = 0;
		y = 0;
		direction = "E";
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public void incrementX() {
		if (x < Constants.MAX_X - 1)
			x++;
	}

	public void incrementY() {
		if (y < Constants.MAX_Y - 1)
			y++;
	}

	public void decrementX() {
		if (x > 0)
			x--;
	}

	public void decrementY() {
		if (y > 0)
			y--;
	}
}

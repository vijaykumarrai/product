package com.robot.executor;

import java.util.List;

import com.robot.drive.SingleJoyStickDrive;
import com.robot.drive.factory.DriveFactory;
import com.robot.util.Util;

public class DriveExecutor {

	public static void executeSingleDrive(String filePath, String drive) {
		try {
			SingleJoyStickDrive driveImpl = DriveFactory.getDrive(drive);

			List<String> commands = Util.getFileContents(filePath);

			driveImpl.startDrive(commands);
		} catch (Exception e) {
			System.out.println("Invalid input for " + drive + " drive. cant execute drive.");
		}
	}

	public static void executeDoubleDrive(String filePath, String drive) {
		try {
			// to be implemented.
		} catch (Exception e) {
			System.out.println("Invalid input for " + drive + " drive. cant execute drive.");
		}
	}
}
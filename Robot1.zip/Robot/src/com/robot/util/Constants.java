package com.robot.util;

public class Constants {
	public static int MAX_X = 5;
	public static int MAX_Y = 5;

	
	//Drive types
	public static String DRIVE_SWERVE = "Swerve";
	public static String DRIVE_ARCADE = "Arcade";
}

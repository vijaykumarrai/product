package com.robot.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Util {
	public static List<String> getFileContents(String filePath) throws IOException {
		List<String> input = new ArrayList<>();

		try {
			input = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
		} catch (IOException e) {
			System.out.println("Invalid file path provided. Can't process request." + e);
			throw e;
		}
		return input;
	}
}

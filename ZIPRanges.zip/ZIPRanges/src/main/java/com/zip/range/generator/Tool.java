package com.zip.range.generator;

import java.util.Scanner;

import com.zip.range.generator.processor.RangeProcessor;

public class Tool {
	
	/**
	 * This is the entry point of the application. Application takes input
	 * through scanner in the format E.g.:- [94133,94133] [94200,94299]
	 * [94600,94699]. This input is converted to int[][] and passed to
	 * Processor. The restrictedList generated from the input is displayed in
	 * the console.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(
				"Please enter the input as space seperated array. E.g.:- [94133,94133] [94200,94299] [94600,94699]");
		String input = sc.nextLine();
		input = input.replaceAll("[^\\dA-Za-z, ]", "").replaceAll("\\s+", " ");

		String[] inputArray = input.split(" ");
		int[][] zipData = new int[inputArray.length][2];
		int i = 0;

		for (String entry : inputArray) {
			String[] entryArray = entry.split(",");
			try {
				zipData[i][0] = Integer.parseInt(entryArray[0].trim());
				zipData[i][1] = Integer.parseInt(entryArray[1].trim());
			} catch (Exception e) {
				System.out.println("Invalid input. Please enter proper zip codes as input.");
				System.exit(-1);
			}
			i++;
		}
		RangeProcessor.calculateRestrictedRanges(zipData);
		RangeProcessor.displayRanges();

	}

}

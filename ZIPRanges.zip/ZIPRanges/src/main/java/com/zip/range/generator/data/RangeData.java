package com.zip.range.generator.data;

import java.util.ArrayList;
import java.util.List;

import com.zip.range.generator.model.Range;

public class RangeData {
	/**
	 * static List which will store the calculation results.
	 */
	private static List<Range> rangeList = new ArrayList<Range>();

	public static List<Range> getRangeList() {
		return rangeList;
	}

	public static void setRangeList(List<Range> rangeList) {
		RangeData.rangeList = rangeList;
	}

}

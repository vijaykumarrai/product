package com.zip.range.generator.processor;

import java.util.ArrayList;
import java.util.List;

import com.zip.range.generator.data.RangeData;
import com.zip.range.generator.model.Range;

public class RangeProcessor {

	/**
	 * This method takes int[][] as input.
	 * Convert each entry of the array into Range object.
	 * Invoke processRange method and add it to the result list based on the algorithm.
	 * 
	 * @param ranges
	 */
	public static void calculateRestrictedRanges(int[][] ranges) {
		try {
			for (int[] input : ranges) {
				Range range = new Range(input[0], input[1]);
				processRange(range);
			}
		} catch (Exception e) {
			System.out.println("Error processing the input.");
			throw e;
		}
	}

	/**
	 * This method takes Range object as input. This object has start and end as data.
	 * Run the alogirthm on the input.
	 * This algorithm checks if the input value range is within the restricted range.
	 * If not add the entry or update the existing entry if overlapping.
	 * 
	 * @param input
	 */
	public static void processRange(Range input) {
		try {
			if (RangeData.getRangeList().size() == 0) {
				RangeData.getRangeList().add(input);
				return;
			}
			boolean addRange = true;
			List<Range> removeList = new ArrayList<>();
			for (Range range : RangeData.getRangeList()) {
				if (input.getStart() >= range.getStart() && input.getEnd() <= range.getEnd()) {
					addRange = false;
				} else if (input.getStart() > range.getEnd() || input.getEnd() < range.getStart()) {
					addRange = true;
				} else if (input.getStart() < range.getStart() && input.getEnd() > range.getEnd()) {
					addRange = true;
				} else if (input.getStart() < range.getStart() && input.getEnd() < range.getEnd()) {
					input.setEnd(range.getEnd());
					removeList.add(range);
					addRange = true;
				} else if (input.getStart() > range.getStart() && input.getEnd() > range.getEnd()) {
					input.setStart(range.getStart());
					removeList.add(range);
					addRange = true;
				}
			}
			if (addRange) {
				RangeData.getRangeList().removeAll(removeList);
				RangeData.getRangeList().add(input);
			}
		} catch (Exception e) {
			System.out.println("Error processing the range " + input);
			throw e;
		}
	}

	/**
	 * This method displays the restricted range results to the console.
	 *  
	 */
	public static void displayRanges() {
		if (RangeData.getRangeList().size() > 0) {
			RangeData.getRangeList().stream().forEach(i -> System.out.println(i.formatString()));
		}
	}
}
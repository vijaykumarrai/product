package com.zip.range.generator.processor;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.zip.range.generator.data.RangeData;
import com.zip.range.generator.model.Range;

public class RangeProcessorTest {
	@Before
	public void setup(){
		RangeData.setRangeList(new ArrayList<Range>());
	}
	
	@Test
	public void testCalculateRestrictedRanges_returns_distinctEntries() {
		int[][] input = {{94133,94133},{94200,94299},{94600,94699}};
		RangeProcessor.calculateRestrictedRanges(input);
		List<Range> rangeList = new ArrayList<Range>();
		Range r1 = new Range(94133,94133);
		Range r2 = new Range(94200,94299);
		Range r3 = new Range(94600,94699);
		rangeList.add(r1);
		rangeList.add(r2);
		rangeList.add(r3);
		assertEquals(rangeList, RangeData.getRangeList());
	}

	@Test
	public void testCalculateRestrictedRanges_returns_mergedList() {
		int[][] input = { { 94133, 94133 }, { 94200, 94299 }, { 94226, 94399 } };
		RangeProcessor.calculateRestrictedRanges(input);
		List<Range> rangeList = new ArrayList<Range>();
		Range r1 = new Range(94133,94133);
		Range r2 = new Range(94200,94399);
		rangeList.add(r1);
		rangeList.add(r2);
		assertEquals(rangeList, RangeData.getRangeList());
	}
}

package com.health.dashboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Service {
	/**
	 * 1. https://dashboard.healthit.gov/api/open-api.php provides the required
	 * data. This API should be invoked with the appropriate input parameters.
	 * 
	 * 2. Call the API using RestTemplate class. The Response will be in JSON
	 * format by default (format can be changed by passing format=xml or csv).
	 * 
	 * 
	 * @param period
	 * @param sortField
	 * @param sortOrder
	 * @return List<List<String>>
	 */
	public List<List<String>> getEHRData(String period, String sortField, String sortOrder) {
		String SERVICE_URL = ServiceConstants.HEALTH_DASHBOARD_SERVICE_URL;
		if (period != null)
			SERVICE_URL += "&period=" + period;
		if (sortField != null)
			SERVICE_URL += "&sort=" + sortField;
		if (sortOrder != null)
			SERVICE_URL += "&sort_dir=" + sortOrder;

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> responseEntity = restTemplate.exchange(SERVICE_URL, HttpMethod.GET, null,
				new ParameterizedTypeReference<String>() {
				});

		String response = responseEntity.getBody();
		List<List<String>> result = mapResponse(response);

		return result;
	}
	
	/**
	 * 1.	Convert the API response to the List<List<String>> where each row represents the data for a region.
	 * 2.	API response is a String containing the data in JSON format.
	 * 3.	Convert JSON to List using the google Gson library.
	 *  
	 * @param response
	 * @return List<List<String>>
	 */
	public List<List<String>> mapResponse(String response) {
		List<List<String>> result = new ArrayList<>();
		if (response != null) {
			JsonParser parser = new JsonParser();
			JsonElement jsonResponse = parser.parse(response);
			JsonObject jsonObject = jsonResponse.getAsJsonObject();

			Set<String> keySet = jsonObject.keySet();
			for (String key : keySet) {
				JsonObject reportData = jsonObject.get(key).getAsJsonObject();
				String region = reportData.get(ServiceConstants.REGION).getAsString();
				String period = reportData.get(ServiceConstants.PERIOD).getAsString();
				String hospitalsEhr = reportData.get(ServiceConstants.PCT_HOSP_BASIC_EHR_NOTES).getAsString();
				String ruralEhr = reportData.get(ServiceConstants.PCT_RURAL_HOSP_BASIC_EHR_NOTES).getAsString();
				String smallEhr = reportData.get(ServiceConstants.PCT_SMALL_HOSP_BASIC_EHR_NOTES).getAsString();
				String criticalEhr = reportData.get(ServiceConstants.PCT_CRITICAL_HOSP_BASIC_EHR_NOTES).getAsString();

				List<String> entry = new ArrayList<>();
				entry.add(region);
				entry.add(period);
				entry.add(hospitalsEhr);
				entry.add(ruralEhr);
				entry.add(smallEhr);
				entry.add(criticalEhr);

				result.add(entry);
			}
		}
		return result;
	}
}

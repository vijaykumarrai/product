package com.health.dashboard;

public class ServiceConstants {
	public static String HEALTH_DASHBOARD_SERVICE_URL = "https://dashboard.healthit.gov/api/open-api.php?source=AHA_2008-2015.csv";
	public static String REGION = "region";
	public static String PERIOD = "period";
	public static String PCT_HOSP_BASIC_EHR_NOTES = "pct_hospitals_basic_ehr_notes";
	public static String PCT_RURAL_HOSP_BASIC_EHR_NOTES = "pct_rural_hospitals_basic_ehr_notes";
	public static String PCT_SMALL_HOSP_BASIC_EHR_NOTES = "pct_small_hospitals_basic_ehr_notes";
	public static String PCT_CRITICAL_HOSP_BASIC_EHR_NOTES = "pct_critical_access_hospitals_basic_ehr_notes";
}
